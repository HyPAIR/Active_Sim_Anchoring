#!/bin/bash
# Launch CoppeliaSim with the workshop scene
# This script opens CoppeliaSim GUI with the anomaly detection scene loaded

# Get the directory where this script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Configuration
PORT=23000

# Auto-detect CoppeliaSim directory in script location
COPPELIA_DIR=$(find "$SCRIPT_DIR" -maxdepth 1 -type d -name "CoppeliaSim*" | head -n 1)

# If not found in script dir, try home directory
if [ -z "$COPPELIA_DIR" ]; then
    COPPELIA_DIR=$(find "$HOME" -maxdepth 1 -type d -name "CoppeliaSim*" | head -n 1)
fi

# Check if CoppeliaSim exists
if [ -z "$COPPELIA_DIR" ] || [ ! -d "$COPPELIA_DIR" ]; then
    echo "ERROR: CoppeliaSim not found!"
    echo "Searched in:"
    echo "  - $SCRIPT_DIR"
    echo "  - $HOME"
    echo ""
    echo "Please ensure CoppeliaSim folder is in the same directory as this script"
    echo "or set COPPELIA_DIR manually in this script"
    exit 1
fi

# Auto-detect scene file (.ttt) in script location
SCENE_FILE=$(find "$SCRIPT_DIR" -maxdepth 1 -type f -name "*.ttt" | head -n 1)

# Check if scene file exists
if [ -z "$SCENE_FILE" ] || [ ! -f "$SCENE_FILE" ]; then
    echo "ERROR: Scene file (.ttt) not found in $SCRIPT_DIR"
    echo ""
    echo "Please ensure a .ttt scene file is in the same directory as this script"
    echo "or set SCENE_FILE manually in this script"
    exit 1
fi

echo "=========================================="
echo "Launching ROSCONFR Workshop"
echo "=========================================="
echo "CoppeliaSim: $COPPELIA_DIR"
echo "Scene:       $SCENE_FILE"
echo "Port:        $PORT"
echo "=========================================="

# Launch CoppeliaSim
cd "$COPPELIA_DIR" || exit 1
./coppeliaSim.sh "$SCENE_FILE" -GzmqRemoteApi.rpcPort=$PORT

echo "CoppeliaSim closed."