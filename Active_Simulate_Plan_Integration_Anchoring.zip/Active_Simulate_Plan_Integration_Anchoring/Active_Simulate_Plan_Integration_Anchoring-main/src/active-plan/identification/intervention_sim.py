"""
Intervention executor for CoppeliaSim.
Handles synchronous shift operations on objects.
"""

import math
import time


class InterventionExecutor:
    """Applies interventions (shifts) to objects in CoppeliaSim."""
    
    def __init__(self, sim_interface, shift_reward=0.0):
        """
        Args:
            sim_interface: CoppeliaSimInterface instance
            shift_reward: Bonus reward for successful shifts
        """
        self.sim = sim_interface.sim
        self.block_handles = sim_interface.block_handles
        self.occ_block_handles = sim_interface.occ_block_handles
        self.shift_reward = shift_reward
    
    def parse_action(self, action):
        """
        Parse action string into direction and magnitude.
        
        Args:
            action: String like 'left,0.005' or 'right,0.01'
            
        Returns:
            (direction, magnitude) or (None, None) if invalid
        """
        try:
            parts = action.split(',')
            if len(parts) != 2:
                return None, None
            
            direction = parts[0].strip()
            magnitude = float(parts[1].strip())
            
            valid_directions = {'left', 'right', 'forward', 'back'}
            if direction not in valid_directions:
                return None, None
            
            return direction, magnitude
            
        except (ValueError, AttributeError):
            return None, None
    
    def apply(self, obj, action):
        """
        Apply intervention to object.
        
        Args:
            obj: Object name ('A', 'B', 'C', 'occ_1')
            action: Action string ('left,0.005')
            
        Returns:
            (success, reward_delta)
        """
        direction, magnitude = self.parse_action(action)
        
        if direction is None or magnitude is None:
            print(f"[InterventionExecutor] Failed to parse action: {action}")
            return False, 0.0
        
        success = self._shift(obj, direction, magnitude)
        reward = self.shift_reward if success else 0.0
        
        return success, reward
    
    def _shift(self, block_name, direction, magnitude):
        """
        Shift block in specified direction.
        
        Args:
            block_name: Name of block ('A', 'B', 'C', 'occ_1')
            direction: 'left', 'right', 'forward', 'back'
            magnitude: Distance in meters
            
        Returns:
            True if successful, False otherwise
        """
        directions = {
            'left': (-magnitude, 0, 0),
            'right': (magnitude, 0, 0),
            'forward': (0, magnitude, 0),
            'back': (0, -magnitude, 0)
        }
        
        if direction not in directions:
            print(f"[Shift] Invalid direction: {direction}")
            return False
        
        dx, dy, dz = directions[direction]
        
        # Get handle
        if block_name.startswith('occ_'):
            if block_name not in self.occ_block_handles:
                print(f"[Shift] Occluder '{block_name}' not found")
                return False
            block_handle = self.occ_block_handles[block_name]
        else:
            if block_name not in self.block_handles:
                print(f"[Shift] Block '{block_name}' not found")
                return False
            block_handle = self.block_handles[block_name]
        
        try:
            current_pos = self.sim.getObjectPosition(block_handle, -1)
            new_pos = [
                current_pos[0] + dx,
                current_pos[1] + dy,
                current_pos[2] + dz
            ]
            self.sim.setObjectPosition(block_handle, -1, new_pos)
            time.sleep(0.05)  # Brief settle time
            return True
            
        except Exception as e:
            print(f"[Shift] Error shifting {block_name}: {e}")
            return False