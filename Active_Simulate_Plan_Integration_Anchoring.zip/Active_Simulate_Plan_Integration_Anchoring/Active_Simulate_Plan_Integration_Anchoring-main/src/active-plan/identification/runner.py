"""
Runner script for MCTS identification.
Provides commands to run nominal, show anomaly, and identify solutions.

Usage:
    python runner.py --mode [nominal|show_anomaly|identify] --anomaly [1|2|3]
"""

import sys
import os
import argparse
import time
import json

# Add parent directories to path
current_dir = os.path.dirname(os.path.abspath(__file__))
src_dir = os.path.dirname(os.path.dirname(current_dir))
sys.path.insert(0, src_dir)

from simulation.coppeliaSim_interface import CoppeliaSimInterface
from simulation.coppeliasim_interface_ur10 import CoppeliaSimInterfaceUR10
from simulation.symbolic_state import SymbolicStateExtractor
from simulation.actions import Actions
from intervention_sim import InterventionExecutor
from mcts_sim import run_mcts_identification


def run_nominal(sim_interface, state_extractor):
    """
    Run nominal stacking - no anomaly, just execute pick/place sequence.
    """
    print("\n" + "="*60)
    print("RUNNING NOMINAL PLAN (No Anomaly)")
    print("="*60)
    
    # Extract initial state
    state = state_extractor.extract_state()
    print("\nInitial State:")
    print(f"  Relationships: {state['relationships']}")
    
    # Create Actions instance
    actions = Actions(sim_interface)
    
    print("\nExecuting Nominal Plan:")
    
    # Step 1: Pick A and place on Goal_1
    print("  1. Pick(A) -> Place(A, Goal_1)")
    success = actions.pick("Block_A", affordance="pick-top")
    if success:
        print("     Pick A: SUCCESS")
    else:
        print("     Pick A: FAILURE")
        return
    
    time.sleep(0.5)
    
    success = actions.place("Block_A", "Goal_1", offset=(0.0, 0.0, 0.0), yaw_offset=0.0)
    if success:
        print("     Place A on Goal_1: SUCCESS")
    else:
        print("     Place A on Goal_1: FAILURE")
        return
    
    time.sleep(0.5)
    
    # Step 2: Pick B and place on A
    print("  2. Pick(B) -> Place(B, A)")
    success = actions.pick("Block_B", affordance="pick-top")
    if success:
        print("     Pick B: SUCCESS")
    else:
        print("     Pick B: FAILURE")
        return
    
    time.sleep(0.5)
    
    success = actions.place("Block_B", "Block_A", offset=(0.0, 0.0, 0.0), yaw_offset=0.0)
    if success:
        print("     Place B on A: SUCCESS")
    else:
        print("     Place B on A: FAILURE")
        return
    
    time.sleep(0.5)
    
    # Step 3: Pick C and place on B
    print("  3. Pick(C) -> Place(C, B)")
    success = actions.pick("Block_C", affordance="pick-top")
    if success:
        print("     Pick C: SUCCESS")
    else:
        print("     Pick C: FAILURE")
        return
    
    time.sleep(0.5)
    
    success = actions.place("Block_C", "Block_B", offset=(0.0, 0.0, 0.0), yaw_offset=0.0)
    if success:
        print("     Place C on B: SUCCESS")
    else:
        print("     Place C on B: FAILURE")
        return
    
    time.sleep(1.0)
    
    # Extract final state
    final_state = state_extractor.extract_state()
    print("\nFinal State:")
    print(f"  Relationships: {final_state['relationships']}")
    print("\nRESULT: Nominal execution complete!")


def show_failure(sim_interface, state_extractor, failure_type):
    """
    Load failure scenario and attempt action to demonstrate failure.
    
    Args:
        failure_type: 'misalignment' or 'occlusion'
    """
    print("\n" + "="*60)
    print(f"SHOWING FAILURE: {failure_type.upper()}")
    print("="*60)
    
    # Determine config file
    if failure_type == 'misalignment':
        config_name = 'misalignment_failure'
    elif failure_type == 'occlusion':
        config_name = 'occlusion_failure'
    else:
        print(f"Error: Unknown failure type '{failure_type}'")
        return
    
    # Load failure scenario
    current_dir = os.path.dirname(os.path.abspath(__file__))
    config_dir = os.path.join(os.path.dirname(current_dir), 'config')
    config_path = os.path.join(config_dir, f"{config_name}.json")
    
    if not os.path.exists(config_path):
        print(f"Error: Config file not found: {config_path}")
        return
    
    sim_interface.generated_dir = config_dir
    sim_interface.load(config_name)
    
    time.sleep(0.5)
    
    # Extract initial state
    state = state_extractor.extract_state()
    print(f"\nLoaded {failure_type} scenario:")
    print(f"  Relationships: {state['relationships']}")
    
    # Create Actions instance
    actions = Actions(sim_interface)
    
    # Execute appropriate action based on failure type
    if failure_type == 'occlusion':
        print("\nAttempting to place B on A (ignoring occlusion)...")
        time.sleep(1.0)
        
        success = actions.pick("Block_B", affordance="pick-top")
        if success:
            print("  Pick B: SUCCESS")
        else:
            print("  Pick B: FAILURE")
            return
        
        time.sleep(0.5)
        
        success = actions.place("Block_B", "Block_A", offset=(0.0, 0.0, 0.0), yaw_offset=0.0)
        if success:
            print("  Place B on A: SUCCESS")
        else:
            print("  Place B on A: FAILURE")
    
    elif failure_type == 'misalignment':
        print("\nAttempting to place C on B (ignoring misalignment)...")
        time.sleep(1.0)
        
        success = actions.pick("Block_C", affordance="pick-top")
        if success:
            print("  Pick C: SUCCESS")
        else:
            print("  Pick C: FAILURE")
            return
        
        time.sleep(0.5)
        
        success = actions.place("Block_C", "Block_B", offset=(0.0, 0.0, 0.0), yaw_offset=0.0)
        if success:
            print("  Place C on B: SUCCESS")
        else:
            print("  Place C on B: FAILURE")
    
    time.sleep(1.0)
    
    # Extract final state
    final_state = state_extractor.extract_state()
    print(f"\nFinal State:")
    print(f"  Relationships: {final_state['relationships']}")
    
    if failure_type == 'misalignment':
        print("\nRESULT: Tower collapsed due to misalignment!")
    elif failure_type == 'occlusion':
        print("\nRESULT: Robot collided with obstacle!")


def show_anomaly(sim_interface, state_extractor, anomaly_num):
    """
    Load and display anomaly without solving.
    """
    print("\n" + "="*60)
    print(f"SHOWING ANOMALY {anomaly_num}")
    print("="*60)
    
    # Load anomaly configuration
    current_dir = os.path.dirname(os.path.abspath(__file__))
    config_dir = os.path.join(os.path.dirname(current_dir), 'config')
    config_path = os.path.join(config_dir, f"anomaly_{anomaly_num}.json")
    
    if not os.path.exists(config_path):
        print(f"Error: Config file not found: {config_path}")
        return
    
    # Set generated_dir to config location
    sim_interface.generated_dir = config_dir
    sim_interface.load(f"anomaly_{anomaly_num}")
    
    time.sleep(0.5)  # Allow sim to settle
    
    # Extract state
    state = state_extractor.extract_state()
    
    print(f"\nLoaded Anomaly {anomaly_num}:")
    print(f"  Block positions:")
    for obj, pos in state['objects'].items():
        if obj in ['A', 'B', 'C']:
            print(f"    {obj}: [{pos[0]:.3f}, {pos[1]:.3f}, {pos[2]:.3f}]")
    
    if 'occ_objects' in state and state['occ_objects']:
        print(f"  Occluder positions:")
        for obj, pos in state['occ_objects'].items():
            print(f"    {obj}: [{pos[0]:.3f}, {pos[1]:.3f}, {pos[2]:.3f}]")
    
    print(f"\n  Relationships: {state['relationships']}")
    
    if 'anomalies' in state and state['anomalies']:
        print(f"  Detected Anomalies: {state['anomalies']}")


def run_identification(sim_interface, state_extractor, anomaly_num, max_iterations=100):
    """
    Load anomaly and run MCTS identification.
    """
    print("\n" + "="*60)
    print(f"RUNNING IDENTIFICATION FOR ANOMALY {anomaly_num}")
    print("="*60)
    
    # Load anomaly
    current_dir = os.path.dirname(os.path.abspath(__file__))
    config_dir = os.path.join(os.path.dirname(current_dir), 'config')
    config_path = os.path.join(config_dir, f"anomaly_{anomaly_num}.json")
    
    if not os.path.exists(config_path):
        print(f"Error: Config file not found: {config_path}")
        return
    
    # Set generated_dir to config location
    sim_interface.generated_dir = config_dir
    sim_interface.load(f"anomaly_{anomaly_num}")
    
    time.sleep(0.5)
    
    # Extract initial state
    initial_state = state_extractor.extract_state()
    print(f"\nInitial State:")
    print(f"  Relationships: {initial_state['relationships']}")
    
    # Create intervention executor
    intervention_executor = InterventionExecutor(sim_interface, shift_reward=0.0)
    
    # Run MCTS
    scenario_config_path = os.path.join(current_dir, "scenario1_intervention.json")
    
    best_sequence, iterations_used = run_mcts_identification(
        sim_interface=sim_interface,
        state_extractor=state_extractor,
        intervention_executor=intervention_executor,
        scenario_config_path=scenario_config_path,
        anomaly_config_dir=config_dir,
        anomaly_name=f"anomaly_{anomaly_num}",
        max_iterations=max_iterations
    )
    
    # Display results
    print("\n" + "="*60)
    print("IDENTIFICATION RESULTS")
    print("="*60)
    
    if best_sequence:
        print(f"\nFinal intervention sequence ({len(best_sequence)} steps):")
        for i, (obj, action) in enumerate(best_sequence, 1):
            print(f"  {i}. Object '{obj}': {action}")
    else:
        print("\nNo solution found within iteration limit.")
    
    print(f"\nTotal iterations: {iterations_used}")
    
    # Save results to file
    output_file = os.path.join(current_dir, f"results_anomaly_{anomaly_num}.json")
    results = {
        'anomaly': f"anomaly_{anomaly_num}",
        'interventions': best_sequence,
        'iterations': iterations_used,
        'solution_found': len(best_sequence) > 0
    }
    
    with open(output_file, 'w') as f:
        json.dump(results, f, indent=2)
    
    print(f"\nResults saved to: {output_file}")


def run_recovery(sim_interface, state_extractor, anomaly_num):
    """
    Load anomaly, apply MCTS interventions, run PDDL planner, execute recovery.
    """
    print("\n" + "="*60)
    print(f"RUNNING RECOVERY FOR ANOMALY {anomaly_num}")
    print("="*60)
    sim_interface.turn_off_box_dynamics()
    # Setup paths
    current_dir = os.path.dirname(os.path.abspath(__file__))
    config_dir = os.path.join(os.path.dirname(current_dir), 'config')
    recovery_dir = os.path.join(os.path.dirname(os.path.dirname(current_dir)), 'recovery')
    
    # Check for pre-made plan
    plan_json_path = os.path.join(
        recovery_dir, "fd_output", f"plan_anomaly_{anomaly_num}.json"
    )
    plan_is_preplanned = False
    if os.path.exists(plan_json_path):
        try:
            with open(plan_json_path, "r") as f:
                plan_steps = json.load(f)
            plan_is_preplanned = bool(plan_steps) and isinstance(plan_steps[0], dict) and "object" in plan_steps[0]
        except Exception:
            plan_is_preplanned = False

    # Load anomaly if available
    print(f"\n[Recovery] Loading anomaly {anomaly_num}...")
    sim_interface.generated_dir = config_dir
    anomaly_file = os.path.join(config_dir, f"anomaly_{anomaly_num}.json")
    if os.path.exists(anomaly_file):
        sim_interface.load(f"anomaly_{anomaly_num}")
        time.sleep(0.5)
    elif not plan_is_preplanned:
        print(f"[Recovery] Error: Anomaly config not found: {anomaly_file}")
        return
    
    # Extract initial state
    initial_state = state_extractor.extract_state()
    print(f"[Recovery] Initial relationships: {initial_state['relationships']}")

    # If a pre-made plan exists, execute it directly and skip MCTS/PDDL
    if plan_is_preplanned:
        try:
            print(f"\n[Recovery] Using pre-made plan: {plan_json_path}")
            sys.path.insert(0, recovery_dir)
            from pddl_to_ompl import execute_preplanned

            success = execute_preplanned(sim_interface, plan_json_path)
            if success:
                final_state = state_extractor.extract_state()
                print(f"\n[Recovery] Final relationships: {final_state['relationships']}")
                print("\n[Recovery] RESULT: Recovery completed successfully!")
            else:
                print("\n[Recovery] RESULT: Recovery failed during execution")
            return
        except Exception as e:
            print(f"[Recovery] Pre-made plan failed, falling back to PDDL: {e}")
    
    # Step 1: Apply MCTS interventions
    print(f"\n[Recovery] Step 1: Applying MCTS interventions...")
    results_file = os.path.join(current_dir, f"results_anomaly_{anomaly_num}.json")

    if not os.path.exists(results_file):
        print(f"[Recovery] Error: Results file not found: {results_file}")
        print(f"[Recovery] Please run identification first: --mode identify --anomaly {anomaly_num}")
        return
    
    with open(results_file, 'r') as f:
        mcts_results = json.load(f)
    
    interventions = mcts_results.get('interventions', [])
    print(f"[Recovery] Found {len(interventions)} interventions to apply")
    
    # Apply interventions
    # intervention_executor = InterventionExecutor(sim_interface, shift_reward=0.0)
    # for obj, action in interventions:
    #     print(f"[Recovery]   Applying: {obj} -> {action}")
    #     success, _ = intervention_executor.apply(obj, action)
    #     if success:
    #         print(f"[Recovery]   SUCCESS")
    #     else:
    #         print(f"[Recovery]   FAILURE")
    #     time.sleep(0.1)
    
    # Check state after interventions
    post_intv_state = state_extractor.extract_state()
    print(f"\n[Recovery] After interventions: {post_intv_state['relationships']}")
    
    # Step 2: Run PDDL planner
    print(f"\n[Recovery] Step 2: Running PDDL planner...")
    sys.path.insert(0, recovery_dir)
    
    try:
        from planner import run_recovery_planning
        from pddl_to_ompl import execute_recovery
        
        plan_actions, target_objects, _ = run_recovery_planning(
            anomaly_num=anomaly_num,
            identification_dir=current_dir,
            config_dir=config_dir,
            recovery_dir=recovery_dir
        )
        
        print(f"\n[Recovery] PDDL plan generated with {len(plan_actions)} actions:")
        for i, (action, params) in enumerate(plan_actions, 1):
            print(f"  {i}. {action} {params}")
        
        # Step 3: Execute recovery plan
        print(f"\n[Recovery] Step 3: Executing recovery plan with OMPL...")
        success = execute_recovery(sim_interface, plan_actions, interventions)
        
        if success:
            # Check final state
            final_state = state_extractor.extract_state()
            print(f"\n[Recovery] Final relationships: {final_state['relationships']}")
            print("\n[Recovery] RESULT: Recovery completed successfully!")
        else:
            print("\n[Recovery] RESULT: Recovery failed during execution")
    
    except Exception as e:
        print(f"\n[Recovery] Error: {e}")
        import traceback
        traceback.print_exc()


def main():
    parser = argparse.ArgumentParser(description='MCTS Identification Runner')
    parser.add_argument(
        '--mode',
        choices=['nominal', 'show_anomaly', 'show_failure', 'identify', 'recover'],
        required=True,
        help='Execution mode'
    )
    parser.add_argument(
        '--anomaly',
        type=int,
        choices=[1, 2, 3, 4, 5],
        help='Anomaly number (required for show_anomaly, identify, and recover modes)'
    )
    parser.add_argument(
        '--failure',
        choices=['misalignment', 'occlusion'],
        help='Failure type (required for show_failure mode)'
    )
    parser.add_argument(
        '--iterations',
        type=int,
        default=100,
        help='MCTS iterations for identify mode (default: 100)'
    )
    parser.add_argument(
        '--port',
        type=int,
        default=23000,
        help='CoppeliaSim ZMQ port (default: 23000)'
    )
    
    args = parser.parse_args()
    
    # Validate arguments
    if args.mode in ['show_anomaly', 'identify', 'recover'] and args.anomaly is None:
        parser.error(f"--anomaly required for mode '{args.mode}'")
    
    if args.mode == 'show_failure' and args.failure is None:
        parser.error("--failure required for mode 'show_failure'")
    
    # Initialize simulator interface
    print(f"Connecting to CoppeliaSim on port {args.port}...")
    # Use UR10 interface for anomalies 4/5 (UR10 + ROBOTIQ85 scene)
    if args.anomaly in [4, 5]:
        sim_interface = CoppeliaSimInterfaceUR10(port=args.port)
    else:
        sim_interface = CoppeliaSimInterface(port=args.port)
    sim_interface.connect()
    sim_interface.initialize_handles()
    sim_interface.turn_on_box_dynamics()
    
    # Create state extractor
    state_extractor = SymbolicStateExtractor(sim_interface)
    
    try:
        # Run selected mode
        if args.mode == 'nominal':
            run_nominal(sim_interface, state_extractor)
        
        elif args.mode == 'show_failure':
            show_failure(sim_interface, state_extractor, args.failure)
        
        elif args.mode == 'show_anomaly':
            show_anomaly(sim_interface, state_extractor, args.anomaly)
        
        elif args.mode == 'identify':
            run_identification(
                sim_interface,
                state_extractor,
                args.anomaly,
                max_iterations=args.iterations
            )
        
        elif args.mode == 'recover':
            run_recovery(sim_interface, state_extractor, args.anomaly)
        
        print("\n" + "="*60)
        print("EXECUTION COMPLETE")
        print("="*60)
    
    except KeyboardInterrupt:
        print("\n\nInterrupted by user")
    
    except Exception as e:
        print(f"\nError: {e}")
        import traceback
        traceback.print_exc()
    
    finally:
        # Keep simulation running for inspection
        print("\nSimulation still running. Press Ctrl+C to exit.")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            print("\nStopping simulation...")
            sim_interface.stop_simulation()


if __name__ == '__main__':
    main()
