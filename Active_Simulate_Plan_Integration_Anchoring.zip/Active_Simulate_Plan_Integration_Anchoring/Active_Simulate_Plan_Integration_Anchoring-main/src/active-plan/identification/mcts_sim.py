"""
Monte Carlo Tree Search for Causal Intervention Planning (Simulator Version).

Follows the structure of Symbolic_Causal_MCTS with canonical MCTS loop:
Select, Expand, Rollout, Backpropagate.

Author: Yazz Warsame
"""

import math
import json
import random
import time
from collections import defaultdict


class MCTSNode:
    """Node in the MCTS tree."""
    
    def __init__(self, interventions=None, parent=None):
        """
        Args:
            interventions: Sequence of (obj, action_str) tuples leading to this state
            parent: Parent MCTSNode or None for root
        """
        self.interventions = interventions or []
        self.parent = parent
        self.children = []
        self.visits = 0
        self.total_reward = 0.0
        self.untried_actions = None
        self.local_violations = set()  # {(obj, direction, magnitude)}


class SymbolicCausalMCTS:
    """MCTS planner for causal anomaly resolution."""
    
    def __init__(
        self,
        sim_interface,
        state_extractor,
        intervention_executor,
        scenario_config,
        alignment_threshold=0.03,
        exploration_constant=1.414,
        max_iterations=100,
        max_rollout_depth=4
    ):
        """
        Args:
            sim_interface: CoppeliaSimInterface instance
            state_extractor: SymbolicStateExtractor instance
            intervention_executor: InterventionExecutor instance
            scenario_config: Dict with intervention space and goal
            alignment_threshold: Distance threshold for alignment (m)
            exploration_constant: UCT exploration parameter
            max_iterations: Maximum MCTS iterations
            max_rollout_depth: Maximum rollout depth
        """
        self.sim_interface = sim_interface
        self.state_extractor = state_extractor
        self.intervention_executor = intervention_executor
        
        self.intervention_space = scenario_config['intv_space']
        self.symbolic_goal = scenario_config['symbolic_goal']
        self.object_priority = scenario_config.get('object_priority', [])
        
        self.alignment_threshold = alignment_threshold
        self.exploration_constant = exploration_constant
        self.max_iterations = max_iterations
        self.max_rollout_depth = max_rollout_depth
        
        # Reward shaping
        reward_cfg = scenario_config.get('reward_shaping', {})
        self.shift_bonus = reward_cfg.get('shift_bonus', 0.0)
        
        # Tracking
        self.visited_seqs = {}
        self.reward_history = []
        self.initial_relationships = set()
        self.critical_on_relations = set()
        
        # Dynamic depth
        self.max_depth = 1
        self._root_just_exhausted = False
        
        # Anomaly tracking for reset
        self.anomaly_config_dir = None
        self.anomaly_name = None

        #Tracking best result
        self.best_reward_found = -float('inf')
        self.best_sequence_found = []

    def set_anomaly_info(self, config_dir, anomaly_name):
        """Set anomaly info for reloading during rollouts."""
        self.anomaly_config_dir = config_dir
        self.anomaly_name = anomaly_name
    
    def search_resolution(self, initial_state, max_iterations=None):
        """
        Main MCTS search loop with depth resolution.
        
        Args:
            initial_state: Initial symbolic state from extractor
            max_iterations: Override max iterations if provided
            
        Returns:
            (best_interventions, iterations_used)
        """
        if max_iterations is None:
            max_iterations = self.max_iterations
        
        print("\n[MCTS] Starting search...")
        print(f"[MCTS] Initial relationships: {initial_state.get('relationships', [])}")
        
        # Store critical relationships
        self.initial_relationships = set(initial_state.get('relationships', []))
        self.critical_on_relations = {
            rel for rel in self.initial_relationships 
            if rel.startswith('On(') and ',Goal_' not in rel
        }
        print(f"[MCTS] Critical relations: {self.critical_on_relations}")
        
        root = MCTSNode(interventions=[])
        root.untried_actions = self.get_legal_actions([], root)
        
        print(f"[MCTS] Total available actions at root: {len(root.untried_actions)}")
        
        start_time = time.time()
        
        for i in range(max_iterations):
            # Select
            node = self.select(root)
            
            # Expand
            child = self.expand(node)
            if child == node:  # No expansion possible
                continue
            
            # Handle depth exhaustion
            exhausted = not root.untried_actions
            if exhausted and not self._root_just_exhausted:
                self.max_depth += 1
                self._root_just_exhausted = True
                print(f"[MCTS] Depth bumped to {self.max_depth}")
            elif not exhausted:
                self._root_just_exhausted = False
            
            # Rollout
            reward = self.rollout(child)
            
            print(f"[ITER {i}] reward={reward:.3f} (interventions={child.interventions}) "
                  f"| depth={len(child.interventions)} | violations={len(child.local_violations)}")
            
            # Backpropagate
            self.backpropagate(child, reward)
            
            # In search loop, after backpropagate:
            if reward > self.best_reward_found:
                self.best_reward_found = reward
                self.best_sequence_found = child.interventions.copy()
                print(f"[MCTS] New best at iter {i}: reward={reward:.3f}, seq={child.interventions}")
              

            # Periodic status
            if (i + 1) % 10 == 0:
                best_child = max(root.children, key=lambda c: c.total_reward / c.visits if c.visits else 0.0) if root.children else None
                best_reward = (best_child.total_reward / best_child.visits) if best_child and best_child.visits else 0.0
                print(f"[MCTS] Iter {i + 1}/{max_iterations}: Root visits={root.visits}, Best={best_reward:.3f}")
        
        elapsed = time.time() - start_time
        print(f"\n[MCTS] Search complete in {elapsed:.2f}s")
        
        # # Return best sequence
        # if root.children:
        #     best = max(root.children, key=lambda c: c.total_reward / c.visits if c.visits else 0.0)
        #     print(f"[MCTS] Best reward: {best.total_reward / best.visits:.3f}")
        #     print(f"[MCTS] Best sequence: {best.interventions}")
        #     return best.interventions, i
        # else:
        #     print("[MCTS] No viable sequences found")
        #     return [], i

        return self.best_sequence_found, i
    
    def select(self, node):
        """Select node to expand using UCT."""
        while True:
            # Can we expand here?
            if len(node.interventions) <= self.max_depth and node.untried_actions:
                return node
            
            # Otherwise descend via UCT
            if node.children:
                node = self._best_child(node)
                # Initialize actions if needed
                if node.untried_actions is None:
                    node.untried_actions = self.get_legal_actions(node.interventions, node)
                continue
            
            return node
    
    def _best_child(self, node):
        """Select child with highest UCT score."""
        best, best_score = None, -float('inf')
        scale = 10000.0  # Scale factor for exploitation
        
        for child in node.children:
            exploit = scale * (child.total_reward / child.visits)
            explore = self.exploration_constant * math.sqrt(math.log(node.visits) / child.visits)
            score = exploit + explore
            
            if score > best_score:
                best, best_score = child, score
        
        return best
    
    def expand(self, node):
        """Expand node by trying an untried action."""
        if node.untried_actions is None:
            node.untried_actions = self.get_legal_actions(node.interventions, node)
        
        while node.untried_actions:
            obj, op = node.untried_actions.pop(0)
            seq = node.interventions + [(obj, op)]
            
            # Check commutativity (visited sequences)
            key = tuple(sorted(seq, key=lambda a: self.object_priority.index(a[0])))
            
            if key in self.visited_seqs:
                continue  # Skip duplicate
            
            self.visited_seqs[key] = True
            
            # Create child
            child = MCTSNode(interventions=seq, parent=node)
            node.children.append(child)
            return child
        
        return node  # No actions left
    
    def get_legal_actions(self, history, node):
        """
        Get all legal (obj, op) action pairs given history.
        
        Enforces rules:
        - No duplicate (obj, op)
        - Only one shift per object
        - Prune known violations
        """
        used_ops_by_obj = defaultdict(set)
        for (o, op) in history:
            used_ops_by_obj[o].add(op)
        
        valid = []
        path_violations = self.collect_violations(node)
        
        for obj, all_ops in self.intervention_space.items():
            done_ops = used_ops_by_obj.get(obj, set())
            
            # Check if object already shifted
            shifted = any(',' in op for op in done_ops)
            
            for op in all_ops:
                # Rule 1: No duplicate (obj, op)
                if op in done_ops:
                    continue
                
                # Rule 2: Only one shift per object
                if ',' in op and shifted:
                    continue
                
                # Rule 3: Prune known violations
                if ',' in op:
                    parts = op.split(',')
                    if len(parts) == 2:
                        direction = parts[0].strip()
                        try:
                            magnitude = float(parts[1].strip())
                            if (obj, direction, magnitude) in path_violations:
                                continue  # Skip this action
                        except ValueError:
                            continue
                
                valid.append((obj, op))
        
        return valid
    
    def collect_violations(self, node):
        """Collect all local_violations from root to current node."""
        violations = set()
        while node:
            violations |= node.local_violations
            node = node.parent
        return violations
    
    def rollout(self, node):
        """
        Perform rollout from node.
        
        Each rollout is a fresh "play":
        1. Reset simulation and reload anomaly
        2. Apply all interventions in sequence
        3. Evaluate final state
        """
        # Reset simulation for fresh evaluation
        self.sim_interface.reset_simulation()
        time.sleep(0.1)  # Allow reset to settle
        
        # Reload anomaly state if configured
        if self.anomaly_config_dir and self.anomaly_name:
            self.sim_interface.generated_dir = self.anomaly_config_dir
            self.sim_interface.load(self.anomaly_name)
            time.sleep(0.1)
        
        # Check for violations in prefix
        path_violations = self.collect_violations(node)
        for obj, axis in node.interventions:
            if ',' in axis:
                parts = axis.split(',')
                direction = parts[0].strip()
                try:
                    magnitude = float(parts[1].strip())
                    if (obj, direction, magnitude) in path_violations:
                        return -1000.0  # Large penalty
                except ValueError:
                    pass
        
        # Apply prefix interventions
        shaped = 0.0
        
        for obj, axis in node.interventions:
            # Apply intervention
            success, score = self.intervention_executor.apply(obj, axis)
            time.sleep(0.05)  # Allow physics to settle
            
            # Get state after intervention
            state = self.state_extractor.extract_state()
            
            # Check for collapse
            if self._is_collapsed(state):
                # Record violation
                if ',' in axis:
                    parts = axis.split(',')
                    direction = parts[0].strip()
                    try:
                        magnitude = float(parts[1].strip())
                        node.local_violations.add((obj, direction, magnitude))
                    except ValueError:
                        pass
                return shaped - 1.0
            
            # Check misalignment
            if not self.check_misalignment(obj, state):
                shaped += 0.25
            else:
                shaped -= 0.25
            

                        
            shaped += score
        
        # Get final state after prefix
        final_state = self.state_extractor.extract_state()
        final_rels = set(final_state.get('relationships', []))

        # Check for occlusion
        rels = final_state.get('relationships', [])
        occlusion_count = sum(1 for rel in rels if rel.startswith('Occluded('))
        shaped -= occlusion_count * 1.0  # -1.0 per occlusion
      
        
        # Calculate final reward based on maintained relations
        maintained = len(self.critical_on_relations & final_rels)
        shaped += maintained / max(len(self.critical_on_relations), 1)
        
        # Suffix: random actions (budget = 0 for now)
        suffix_budget = 0
        rollout_history = node.interventions.copy()
        
        for _ in range(suffix_budget):
            valid = self.get_legal_actions(rollout_history, node)
            if not valid:
                break
            
            obj, axis = random.choice(valid)
            rollout_history.append((obj, axis))
            
            # Apply
            success, score = self.intervention_executor.apply(obj, axis)
            time.sleep(0.05)
            state = self.state_extractor.extract_state()
            
            if self._is_collapsed(state):
                return shaped
            
            if not self.check_misalignment(obj, state):
                shaped += 0.25
            
            shaped += score
        
        # Record history
        self.reward_history.append({
            "interventions": rollout_history.copy(),
            "shaped": shaped,
        })
        
        return shaped
    
    def backpropagate(self, node, reward):
        """Backpropagate reward up the tree."""
        while node is not None:
            node.visits += 1
            node.total_reward += reward
            node = node.parent
    
    def _is_collapsed(self, state):
        """Check if tower has collapsed."""
        current_rels = set(state.get('relationships', []))
        
        for critical_rel in self.critical_on_relations:
            if critical_rel not in current_rels:
                return True
        
        return False
    
    def check_misalignment(self, obj, state):
        """
        Check if object is misaligned on its support.
        
        Args:
            obj: Object name
            state: Current state dict
            
        Returns:
            True if misaligned (beyond threshold)
        """
        positions = state.get('objects', {})
        relationships = state.get('relationships', [])
        
        # Find what obj is on
        support = None
        for rel in relationships:
            if rel.startswith(f'On({obj},') and ',Goal_' not in rel:
                parts = rel[3:-1].split(',')
                if len(parts) == 2:
                    support = parts[1]
                    break
        
        if not support or support not in positions or obj not in positions:
            return False
        
        pos_obj = positions[obj]
        pos_support = positions[support]
        
        dx = abs(pos_obj[0] - pos_support[0])
        dy = abs(pos_obj[1] - pos_support[1])
        print(f"dx = {dx} | dy = {dy}")
        return dx > self.alignment_threshold or dy > self.alignment_threshold


def load_scenario_config(config_path):
    """Load scenario configuration from JSON."""
    with open(config_path, 'r') as f:
        return json.load(f)


def run_mcts_identification(
    sim_interface,
    state_extractor,
    intervention_executor,
    scenario_config_path,
    anomaly_config_dir=None,
    anomaly_name=None,
    max_iterations=100
):
    """
    Run MCTS identification on current simulator state.
    
    Args:
        sim_interface: CoppeliaSimInterface
        state_extractor: SymbolicStateExtractor
        intervention_executor: InterventionExecutor
        scenario_config_path: Path to scenario JSON
        anomaly_config_dir: Directory containing anomaly configs
        anomaly_name: Name of anomaly file (without .json)
        max_iterations: MCTS iterations
        
    Returns:
        (best_sequence, iterations_used)
    """
    # Load config
    config = load_scenario_config(scenario_config_path)
    
    # Get initial state
    initial_state = state_extractor.extract_state()
    
    # Create planner
    planner = SymbolicCausalMCTS(
        sim_interface=sim_interface,
        state_extractor=state_extractor,
        intervention_executor=intervention_executor,
        scenario_config=config,
        alignment_threshold=0.006,
        exploration_constant=1.414,
        max_iterations=max_iterations,
        max_rollout_depth=config.get('max_rollout_depth', 4)
    )
    
    # Set anomaly info for reloading during rollouts
    if anomaly_config_dir and anomaly_name:
        planner.set_anomaly_info(anomaly_config_dir, anomaly_name)
    
    # Run search
    best_sequence, iterations = planner.search_resolution(initial_state, max_iterations)
    
    return best_sequence, iterations