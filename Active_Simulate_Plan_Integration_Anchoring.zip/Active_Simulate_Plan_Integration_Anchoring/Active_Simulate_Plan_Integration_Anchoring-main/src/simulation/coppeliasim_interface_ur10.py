"""
CoppeliaSim Interface for UR10 + ROBOTIQ85 Assembly Scene.

Follows the same pattern as the original coppeliaSim_interface.py,
just configured for the UR10 scene (Integration-meeting-genoa-WP3.ttt).
"""

from coppeliasim_zmqremoteapi_client import RemoteAPIClient
import time
import json
import os


class CoppeliaSimInterfaceUR10:
    def __init__(self, port: int = 23000):
        self.client = RemoteAPIClient('localhost', port)
        self.sim = self.client.getObject('sim')
        self.simIK = self.client.require('simIK')

        self.joint_handles = []
        self.block_handles = {}
        self.occ_block_handles = {}
        self.goal_handles = {}
        self.robot_handles = {}
        self.table_1 = None
        self.table_2 = None

        self.robot_tip_handle = None
        self.gripper_base_handle = None
        self.target_dummy = None
        self.robot_base_handle = None

        self.generated_dir = '/home/yazz/Desktop/Active_Simulate_Plan_V1/anomaly_generator/examples'

        # OMPLement expected names for UR10 scene
        self.OMPLEMENT = {
            "robot_name": os.environ.get("OMPL_ROBOT_NAME", "UR10"),
            "robot_gripper": os.environ.get("OMPL_ROBOT_GRIPPER", "UR10/ROBOTIQ85"),
            "target_rel": os.environ.get("OMPL_TARGET_REL", "target"),
        }

    def connect(self):
        self.sim.startSimulation()
        while self.sim.getSimulationState() == self.sim.simulation_stopped:
            time.sleep(0.01)
        print('[Coppelia] Connected.')

    def stop_simulation(self):
        self.sim.stopSimulation()
        while self.sim.getSimulationState() != self.sim.simulation_stopped:
            time.sleep(0.01)
        print('[Coppelia] Stopped.')

    def reset_simulation(self):
        self.sim.stopSimulation()
        time.sleep(0.1)
        print('Simulation stopped for reset')
        time.sleep(0.1)
        self.sim.startSimulation()
        self.turn_on_box_dynamics()
        print('Simulation restarted')

    def turn_off_box_dynamics(self) -> None:
        """Disables physics for all blocks."""
        for block in self.block_handles.values():
            self.sim.setObjectInt32Parameter(block, 3003, 1)

    def turn_on_box_dynamics(self) -> None:
        """Enables physics for all blocks."""
        for block in self.block_handles.values():
            self.sim.setObjectInt32Parameter(block, 3003, 0)

    def load(self, template_name: str) -> None:
        """Loads a generated anomaly example into the simulation."""
        load_path = os.path.join(self.generated_dir, f"{template_name}.json")
        if not os.path.exists(load_path):
            raise FileNotFoundError(f"No saved anomaly found at {load_path} with name {template_name}")

        with open(load_path, 'r') as f:
            block_positions = json.load(f)

        for block_name, position in block_positions.items():
            if block_name in self.block_handles:
                self.sim.setObjectPosition(self.block_handles[block_name], -1, position)
            elif block_name in self.occ_block_handles:
                self.sim.setObjectPosition(self.occ_block_handles[block_name], -1, position)
            else:
                print(f"[Load] Warning: '{block_name}' not found in block_handles or occ_block_handles")

        print(f"[Load] Loaded {len(block_positions)} objects from {template_name}")

    def _try_get(self, name):
        try:
            return self.sim.getObject(name)
        except Exception:
            return None

    def initialize_handles(self):
        # ============ BLOCKS / MANIPULATED OBJECTS ============
        # UR10 scene objects
        for k in ['A60', 'A60_1_2']:
            h = self._try_get(f'/{k}')
            if h is not None:
                self.block_handles[k] = h

        if not self.block_handles:
            print('[Warning] No block handles found')

   
        # Robot tip candidates
        candidates_tip = [
            '/left_base_link_respondable',
            '/Panda/Panda_gripper/tip',
            '/LBRiiwa14R820/connection/tip',
            '/UR10/tip',
        ]
        for nm in candidates_tip:
            h = self._try_get(nm)
            if h:
                self.robot_tip_handle = h
                break
        if not self.robot_tip_handle:
            raise RuntimeError('Robot tip not found.')

        # Gripper candidates
        candidates_gripper = [
            '/left_base_link_respondable/Panda_gripper',
            '/Panda/Panda_gripper',
            '/UR10/gripper',
        ]
        for nm in candidates_gripper:
            h = self._try_get(nm)
            if h:
                self.gripper_base_handle = h
                break

        if not self.gripper_base_handle:
            self.gripper_base_handle = self.robot_tip_handle

        # ============ ROBOT BASE ============
        base = self._try_get('/' + self.OMPLEMENT["robot_name"])
        if not base:
            base = self._try_get('/UR10')
        if not base:
            base = self.robot_tip_handle
        self.robot_base_handle = base
        if self.robot_base_handle:
            try:
                base_alias = self.sim.getObjectAlias(self.robot_base_handle)
                if base_alias:
                    self.OMPLEMENT["robot_name"] = base_alias
            except Exception:
                pass

        # ============ ROBOT HANDLES DICT ============
        self.robot_handles['tip'] = self.robot_tip_handle
        self.robot_handles['gripper'] = self.gripper_base_handle
        self.robot_handles['base'] = self.robot_base_handle

        # ============ JOINTS ============
        for i in range(1, 7):
            h = self._try_get(f'/UR10/joint{i}')
            if h:
                self.joint_handles.append(h)

        # ============ TABLES / GOALS ============
        # Assembly structure as table/goal
        self.table_1 = self._try_get('/Assembly')
        self.table_2 = self._try_get('/Assembly/base_second_layer')

        # Target locations
        for target_name in ['A60_1_2_D', 'targetA60_1_2']:
            h = self._try_get(f'/Assembly/{target_name}') or self._try_get(f'/{target_name}')
            if h:
                # Store with a simple key
                self.goal_handles[target_name] = h

        # ============ ENSURE OMPL TARGET DUMMY ============
        target_alias = self.OMPLEMENT["target_rel"]
        target_path = f'/{self.OMPLEMENT["robot_name"]}/{target_alias}'
        t = self._try_get(target_path)
        if not t:
            try:
                t = self.sim.createDummy(0.01)
                self.sim.setObjectAlias(t, target_alias)
                self.sim.setObjectParent(t, self.robot_base_handle, True)
                self.sim.setObjectPosition(t, -1, [0, 0, 0.2])
                self.sim.setObjectOrientation(t, -1, [0, 0, 0])
            except Exception:
                t = None
        self.target_dummy = t
        self.robot_handles['target'] = self.target_dummy

        print('[Coppelia] Handles initialized:',
              f'blocks={list(self.block_handles.keys())}, '
              f'goals={list(self.goal_handles.keys())}, '
              f'tip={self.robot_tip_handle}, '
              f'gripper={self.gripper_base_handle}')

    def _shape_dims(self, sim, handle):
        res = sim.getShapeGeomInfo(handle)
        try:
            _, _, dims = res
        except Exception:
            dims = res[2]
        sx, sy, sz = float(dims[0]), float(dims[1]), float(dims[2])
        return [sx, sy, sz]

    def _collect_dimensions(self, sim, block_handles: dict, occ_handles: dict, goal_handles: dict):
        block_dims = {}
        occ_dims = {}
        goal_dims = {}
        for name, h in block_handles.items():
            try:
                block_dims[name] = self._shape_dims(sim, h)
            except:
                block_dims[name] = [0.1, 0.1, 0.1]
        for name, h in occ_handles.items():
            try:
                occ_dims[name] = self._shape_dims(sim, h)
            except:
                occ_dims[name] = [0.1, 0.1, 0.1]
        for gid, h in goal_handles.items():
            try:
                goal_dims[gid] = self._shape_dims(sim, h)
            except:
                goal_dims[gid] = [0.1, 0.1, 0.1]
        return block_dims, occ_dims, goal_dims

    def get_current_state(self) -> dict:
        blocks = {k: self.sim.getObjectPosition(h, -1) for k, h in self.block_handles.items()}
        blocks_R = {k: self.sim.getObjectOrientation(h, -1) for k, h in self.block_handles.items()}

        occ = {k: self.sim.getObjectPosition(h, -1) for k, h in self.occ_block_handles.items()}
        goals = {k: self.sim.getObjectPosition(h, -1) for k, h in self.goal_handles.items()}
        tip = self.sim.getObjectPosition(self.robot_handles['tip'], -1) if 'tip' in self.robot_handles else [0, 0, 0]

        table1_p = self.sim.getObjectPosition(self.table_1, -1) if self.table_1 else [0, 0, 0]
        table2_p = self.sim.getObjectPosition(self.table_2, -1) if self.table_2 else [0, 0, 0]
        block_dims, occ_dims, goal_dims = self._collect_dimensions(self.sim, self.block_handles, self.occ_block_handles, self.goal_handles)

        return {
            'block_positions': blocks,
            'block_orientations': blocks_R,
            'block_dimensions': block_dims,
            'occ_block_positions': occ,
            'occ_block_dimensions': occ_dims,
            'gripper_position': tip,
            'goal_position': goals,
            'goal_dimensions': goal_dims,
            'table_1_position': table1_p,
            'table_2_position': table2_p,
            'intervened_objects': [],
        }


# ============================================================
# TEST
# ============================================================

if __name__ == '__main__':
    print("=" * 60)
    print("Testing CoppeliaSim Interface for UR10")
    print("=" * 60)

    interface = CoppeliaSimInterfaceUR10(port=23000)
    interface.connect()
    interface.initialize_handles()

    state = interface.get_current_state()
    print(f"\nBlocks: {list(state['block_positions'].keys())}")
    print(f"Goals: {list(state['goal_position'].keys())}")
    
    for name, pos in state['block_positions'].items():
        print(f"  {name}: [{pos[0]:.3f}, {pos[1]:.3f}, {pos[2]:.3f}]")

    print("\n" + "=" * 60)
    print("Interface ready for Actions class")
    print("=" * 60)
