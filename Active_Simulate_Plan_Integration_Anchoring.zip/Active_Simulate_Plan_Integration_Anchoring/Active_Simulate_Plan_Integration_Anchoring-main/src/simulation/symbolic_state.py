"""
Symbolic state extractor
- Emits planning relationships only: On/OnGoal/OnTable/Clear/Holding
- Anomalies are produced by detection.anomaly_detection.tag_anomalies
"""
import time
from typing import Dict, Any, List
from simulation.coppeliaSim_interface import CoppeliaSimInterface
import json

class SymbolicStateExtractor:
    def __init__(self, sim_interface: CoppeliaSimInterface):
        self.sim_interface = sim_interface

    def extract_state(self) -> Dict[str, Any]:
        st = self.sim_interface.get_current_state()
        rels = self._extract_relationships(st)
        tags, meta = None, None

        return {
            'timestamp': int(time.time()),
            'objects': st['block_positions'],
            'objects_R': st.get('block_orientations', {}),
            'occ_objects': st.get('occ_block_positions', {}),
            'gripper_position': st['gripper_position'],
            'goal_position': st['goal_position'],
            'table_1_position': st.get('table_1_position', [0,0,0]),
            'block_dimensions': st.get('block_dimensions', {}),
            'occ_block_dimensions': st.get('occ_block_dimensions', {}),
            'goal_dimensions': st.get('goal_dimensions', {}),
            'relationships': rels,
            'anomalies': tags,
            'anomaly_meta': meta,
            'intervened_objects': [],
        }

    def _extract_relationships(self, state: Dict[str, Any]) -> List[str]:
        rels: List[str] = []

        blocks = state['block_positions']
        occ_blocks = state['occ_block_positions']
        b_dims = state.get('block_dimensions', {})
        goals  = state['goal_position']
        g_dims = state.get('goal_dimensions', {})
        tip    = state['gripper_position']
        table_z = state.get('table_1_position', [0,0,0])[2]


        def is_near(position_u, position_v, xy_threshold=0.30):
            """
            Determines if one object is stacked on another.

            Args:
                position_u (list): [x, y, z] position of the upper object.
                position_v (list): [x, y, z] position of the lower object.
                xy_threshold (float): Horizontal alignment threshold.

            Returns:
                bool: True if position_u is near position_v, otherwise False.
            """
            #print(f"val1 -> {abs(position_u[0] - position_v[0])} | val2 -> {abs(position_u[1] - position_v[1])}")
            if abs(position_u[0] - position_v[0]) < xy_threshold and abs(position_u[1] - position_v[1]) < xy_threshold:
                return True
            
            return False

        def near_xyz(p, q, r):
            dx,dy,dz = p[0]-q[0], p[1]-q[1], p[2]-q[2]
            return (dx*dx+dy*dy+dz*dz) ** 0.5 <= r

        def near_xy(p, q, r):
            dx,dy = p[0]-q[0], p[1]-q[1]
            return (dx*dx+dy*dy) ** 0.5 <= r

        # Holding
        for k,p in blocks.items():
            if near_xyz(p, tip, 0.10):
                rels.append(f'Holding({k})')

        # On(u,v) for blocks
        def on_block(u, v):
            pu, pv = blocks[u], blocks[v]
            sz_u = b_dims.get(u, [0.059,0.059,0.059])[2]
            sz_v = b_dims.get(v, [0.059,0.059,0.059])[2]
            dz = abs((pu[2]-pv[2]) - (sz_u/2.0 + sz_v/2.0))
            return dz <= 0.012 and near_xy(pu, pv, 0.03)

        # On(u,Goal_k)
        def on_goal(u, gid):
            pu, pg = blocks[u], goals[gid]
            sz_u = b_dims.get(u, [0.059,0.059,0.059])[2]
            # goal.z is its CENTER; expect sz_goal/2 + sz_u/2
            sz_g = g_dims.get(gid, [0.13,0.13,0.02])[2]
            dz = abs((pu[2]-pg[2]) - (sz_g/2.0 + sz_u/2.0))
            return dz <= 0.012 and near_xy(pu, pg, 0.03)

        # On / OnGoal
        on_any = set()
        for u in blocks:
            for v in blocks:
                if u==v: continue
                if on_block(u, v):
                    rels.append(f'On({u},{v})')
                    on_any.add(u)
            for gid in goals:
                if on_goal(u, gid):
                    rels.append(f'On({u},Goal_{gid})')
                    on_any.add(u)

        # OnTable (only when not on something else)
        for k,p in blocks.items():
            if k in on_any:  # already supported by something
                continue
            h = b_dims.get(k, [0.059,0.059,0.059])[2]
            if abs(p[2] - (table_z + h/2.0)) <= 0.02:
                rels.append(f'On({k},Table_1)')

        # Clear(k): nothing above it (near in XY and higher in Z)
        above = {k:set() for k in blocks}
        by_z = sorted(blocks.items(), key=lambda kv: kv[1][2])
        for i,(vk,pv) in enumerate(by_z):
            for j in range(i+1,len(by_z)):
                uk,pu = by_z[j]
                if near_xy(pu,pv,0.08) and pu[2] > pv[2]:
                    above[vk].add(uk)
        for k in blocks:
            if not above[k]:
                pass
                #rels.append(f'Clear({k})')
        
        # --------------------------
        # Handling Occlusion/ Infront
        # --------------------------
        for block_name, pos in blocks.items():
            for occ_block_name, occ_pos in occ_blocks.items():
                if is_near(occ_pos, pos):  
                    rels.append(f"Occluded({block_name}, {occ_block_name})")

        return rels

    def save_to_json(self, state, filename="symbolic_state.json"):
            """
            Saves the extracted symbolic state to a JSON file.

            Args:
                filename (str): Name of the output JSON file.
            """
            with open(filename, "w") as json_file:
                json.dump(state, json_file, indent=4)