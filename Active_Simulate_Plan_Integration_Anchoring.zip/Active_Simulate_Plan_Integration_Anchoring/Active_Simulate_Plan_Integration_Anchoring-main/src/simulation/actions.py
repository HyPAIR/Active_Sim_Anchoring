import time, math
from simulation.driver import Interfacer
import os 

from typing import Tuple
class Actions:
    def __init__(self, coppelia_interface):
        self.sim = coppelia_interface.sim
        self.robot_handles = coppelia_interface.robot_handles
        self.block_handles = coppelia_interface.block_handles
        self.occ_block_handles = getattr(coppelia_interface, "occ_block_handles", {})
        self.gripper_base_handle = coppelia_interface.gripper_base_handle

        # OMPLement expected names (override per scene if needed)
        self.OMPLEMENT = getattr(
            coppelia_interface,
            "OMPLEMENT",
            {
                "robot_name": os.environ.get("OMPL_ROBOT_NAME", "left_base_link_respondable"),
                "robot_gripper": os.environ.get("OMPL_ROBOT_GRIPPER", "left_base_link_respondable/Panda_gripper"),
                "target_rel": os.environ.get("OMPL_TARGET_REL", "target"),
            },
        )
        # Initialize OMPL-based planner
        self.planner = Interfacer(
            scene_file_name=None,
            robot_name=self.OMPLEMENT["robot_name"],
            robot_gripper=self.OMPLEMENT["robot_gripper"],
        )
        self.planner.start()

    # ---------------- helpers ----------------
    def _get_handle_by_name(self, name: str):
        try:
            return self.sim.getObject('/' + name if not name.startswith('/') else name)
        except Exception:
            return None

    def _attach(self, block_name: str):
        h = self._get_handle_by_name(block_name)
        if not h:
            return False
        self.sim.setObjectInt32Parameter(h, 3003, 1)
        time.sleep(0.2)
        self.sim.resetDynamicObject(h)
        time.sleep(0.2)
        self.sim.setObjectParent(h, self.gripper_base_handle, True)
        time.sleep(0.2)
        return True

    def _detach(self, block_name: str):
        h = self._get_handle_by_name(block_name)
        if not h:
            return False
        self.sim.setObjectParent(h, -1, True)
        time.sleep(0.2)
        self.sim.setObjectInt32Parameter(h, 3003, 0)
        time.sleep(0.5)
        self.sim.setObjectInt32Parameter(h, 3003, 1)
        return True

    def _get_dims(self, name: str):
        """Return (sx, sy, sz) for a shape by name ('Block_A', 'Goal_1', '/occ_1', etc.)."""
        h = self._get_handle_by_name(name)
        if not h:
            return (0.06, 0.06, 0.06)
        res = self.sim.getShapeGeomInfo(h)
        try:
            _, _, dims = res
        except Exception:
            dims = res[2]
        return float(dims[0]), float(dims[1]), float(dims[2])

    def _get_pos(self, name: str):
        h = self._get_handle_by_name(name)
        return self.sim.getObjectPosition(h, -1) if h else [0.0, 0.0, 0.0]

    def _set_pos(self, name: str, p):
        h = self._get_handle_by_name(name)
        if h:
            self.sim.setObjectPosition(h, -1, p)

    def _get_euler(self, name: str):
        h = self._get_handle_by_name(name)
        return self.sim.getObjectOrientation(h, -1) if h else [0.0, 0.0, 0.0]

    def _set_euler(self, name: str, e):
        h = self._get_handle_by_name(name)
        if h:
            self.sim.setObjectOrientation(h, -1, e)

    def _is_goal(self, name: str) -> bool:
        s = name.lower()
        return ("goal" in s) or (s == "/goal") or (s.endswith("_goal"))

    # ---------------- API ----------------
    def pick(self, block_name: str, affordance: str = "pick-top") -> bool:
        # e.g., 'Block_A'
        print(f"[Pick] Attempting to pick {block_name} with affordance '{affordance}'")
        goal_poses = self.planner.ompl_find_pose(block_name, affordance)
        if not goal_poses:
            print(f"[Pick] No feasible pose found for {block_name}.")
            return False
        success = self.planner.ompl_path_planning(
            target_object=block_name,
            goal_pose=goal_poses[0],
            ompl_args={
                "ompl_state_resolution": 0.006,
                "ompl_use_lua": True,
                "ompl_algorithm": "RRTConnect",
                "ompl_motion_constraint": "free",
                "ompl_use_state_validation": False
               # "ompl_max_simplify": 2.0,  # ADD THIS - 2 seconds for path smoothing
            },
        )
        if not success:
            print(f"[Pick] Motion planning failed for {block_name}.")
            return False

        ok = self._attach(block_name)
        if ok:
            print(f"[Pick] Picked up {block_name} successfully.")
        
        # goal_poses = self.planner.ompl_find_pose("T1_Dummy", affordance)
        # if not goal_poses:
        #     print(f"[Pick] No feasible pose found for t1_dummy.")
        #     return False
        # success = self.planner.ompl_path_planning(
        #     target_object="T1_Dummy",
        #     goal_pose=goal_poses[0],
        #     ompl_args={
        #         "ompl_state_resolution": 0.005,
        #         "ompl_use_lua": True,
        #         "ompl_algorithm": "RRTConnect",
        #         "ompl_motion_constraint": "free",
        #     },
        # )
        # if not success:
        #     print(f"[Pick] Motion planning failed for T1_Dummy.")
        #     return False


        return ok

    def place(
    self,
    block_name: str,
    target_name: str,
    affordance: str = "place-top",
    offset: Tuple[float, float, float] = (0.0, 0.0, 0.0),
    yaw_offset: float = 0.0,
    settle_sec: float = 1.5,
) -> bool:
        """
        Place block on target with optional offset.
        
        Uses dummy target approach: creates a dummy at the offset location,
        plans to that dummy, then detaches. This creates physically plausible
        placement errors rather than artificial post-placement perturbations.
        
        Args:
            block_name: Name of block to place (e.g., "Block_A")
            target_name: Name of target (e.g., "Block_B", "Goal_1")
            affordance: Placement affordance type
            offset: (dx, dy, dz) offset in meters from nominal placement
            yaw_offset: Yaw rotation offset in radians
            settle_sec: Seconds to wait for physics settling
        
        Returns:
            True if placement succeeded, False otherwise
        """
        print(f"[Place] {block_name} on {target_name} | "
            f"offset=({offset[0]:.4f}, {offset[1]:.4f}, {offset[2]:.4f}) | "
            f"yaw={math.degrees(yaw_offset):.1f}°")
        
        # Get nominal placement pose
        goal_poses = self.planner.ompl_find_pose(target_name, affordance)
        if not goal_poses:
            print(f"[Place] No feasible placement pose found for {target_name}")
            return False
        
        # goal_poses[0] is a 7-element array: [x, y, z, qx, qy, qz, qw]
        nominal_pose = goal_poses[0]
        
        # Extract position and quaternion
        nominal_pos = nominal_pose[:3]  # [x, y, z]
        nominal_quat = nominal_pose[3:]  # [qx, qy, qz, qw]
        
        # Apply offset to position
        perturbed_pos = [
            nominal_pos[0] + offset[0],
            nominal_pos[1] + offset[1],
            nominal_pos[2] + offset[2]
        ]
        
        # For orientation, we need to:
        # 1. Convert quaternion to Euler angles (to get current yaw)
        # 2. Add yaw_offset
        # 3. Convert back to quaternion for OMPL
        # 4. Also convert to Euler for the dummy
        
        # Convert quaternion to Euler
        qx, qy, qz, qw = nominal_quat
        
        # Euler from quaternion (roll, pitch, yaw)
        # Roll (alpha)
        sinr_cosp = 2 * (qw * qx + qy * qz)
        cosr_cosp = 1 - 2 * (qx * qx + qy * qy)
        roll = math.atan2(sinr_cosp, cosr_cosp)
        
        # Pitch (beta)
        sinp = 2 * (qw * qy - qz * qx)
        if abs(sinp) >= 1:
            pitch = math.copysign(math.pi / 2, sinp)
        else:
            pitch = math.asin(sinp)
        
        # Yaw (gamma)
        siny_cosp = 2 * (qw * qz + qx * qy)
        cosy_cosp = 1 - 2 * (qy * qy + qz * qz)
        yaw = math.atan2(siny_cosp, cosy_cosp)
        
        # Apply yaw offset
        perturbed_yaw = yaw + yaw_offset
        
        # Euler angles for dummy (CoppeliaSim uses Euler)
        perturbed_euler = [roll, pitch, perturbed_yaw]
        
        # Convert back to quaternion for OMPL
        cy = math.cos(perturbed_yaw * 0.5)
        sy = math.sin(perturbed_yaw * 0.5)
        cp = math.cos(pitch * 0.5)
        sp = math.sin(pitch * 0.5)
        cr = math.cos(roll * 0.5)
        sr = math.sin(roll * 0.5)
        
        perturbed_qw = cr * cp * cy + sr * sp * sy
        perturbed_qx = sr * cp * cy - cr * sp * sy
        perturbed_qy = cr * sp * cy + sr * cp * sy
        perturbed_qz = cr * cp * sy - sr * sp * cy
        
        perturbed_quat = [perturbed_qx, perturbed_qy, perturbed_qz, perturbed_qw]
        
        # Create dummy at perturbed location
        dummy = self.sim.createDummy(0.0001)
        self.sim.setObjectPosition(dummy, -1, perturbed_pos)
        self.sim.setObjectOrientation(dummy, -1, perturbed_euler)
        
        print(f"[Place] Created dummy at perturbed pose")
        
        # Construct full 7-element pose for OMPL
        perturbed_pose = perturbed_pos + perturbed_quat
        
        # Plan motion to dummy (this is the potentially "wrong" location)
        success = self.planner.ompl_path_planning(
            target_object=block_name,
            goal_pose=perturbed_pose,  # Pass as 7-element list
            ompl_args={
                "ompl_state_resolution": 0.006,
                "ompl_use_lua": True,
                "ompl_algorithm": "RRTConnect",
                #"ompl_motion_constraint": "free",
                 "ompl_use_state_validation": False
               # "ompl_max_simplify": 2.0,  # ADD THIS - 2 seconds for path smoothing
            }
        )
        
        if not success:
            print(f"[Place] Motion planning failed")
            self.sim.removeObject(dummy)
            return False
        
        # Detach at this (potentially offset) location
        ok = self._detach(block_name)
        
        # Clean up dummy
        self.sim.removeObject(dummy)
        
        if not ok:
            print(f"[Place] Detach failed")
            return False
        
        # Wait for physics to settle (critical for overturn detection)
        time.sleep(settle_sec)
        
        print(f"[Place] Completed successfully")
        return True

    # ---------------- occluder convenience ----------------
    def move_occ1_near(self, anchor_name: str, ox: float, oy: float, mode: str = "occlusion", settle_sec: float = 0.2) -> bool:
        """
        Move '/occ_1' near an anchor (Goal_1 or Block_X).
        mode:
          - 'obstruction' -> center at the anchor's top band (sits on top)
          - 'occlusion'   -> near in XY but Z is well below the top band
        """
        occ_h = self._get_handle_by_name('/occ_1')
        if not occ_h:
            print("[Occ] '/occ_1' not found; skipping.")
            return False

        # Anchor pose & top-z
        p_a = self._get_pos(anchor_name)
        if self._is_goal(anchor_name):
            top_z = p_a[2]  # goal z is the top surface by convention
        else:
            _, _, ah = self._get_dims(anchor_name)
            top_z = p_a[2] + ah/2.0

        # Occ size
        osx, osy, oh = self._get_dims('/occ_1')

        if mode == "obstruction":
            # sit on top: occ center at top_z + half its height
            z = top_z + oh/2.0
        else:
            # occlusion: far enough below top band so it won't trigger obstruction
            z = top_z - (oh/2.0 + 0.12)  # 12 cm below the top band

        pos = [p_a[0] + ox, p_a[1] + oy, z]
        self.sim.setObjectPosition(occ_h, -1, pos)
        time.sleep(settle_sec)
        print(f"[Occ] Moved occ_1 near {anchor_name} with mode='{mode}', pos={pos}")
        return True
