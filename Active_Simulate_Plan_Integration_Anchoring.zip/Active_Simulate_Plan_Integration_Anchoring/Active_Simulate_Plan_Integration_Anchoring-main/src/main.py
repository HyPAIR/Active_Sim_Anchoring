"""
Simple Test: Pick and Place with UR10 + ROBOTIQ85

Tests that the basic pick/place workflow works with the new interface.

Usage:
    1. Open CoppeliaSim with Integration-meeting-genoa-WP3.ttt
    2. Start simulation
    3. Run: python src/main.py
"""

import os
import time

# Set environment variables BEFORE imports
os.environ["OMPL_ROBOT_NAME"] = "left_base_link_respondable10"
os.environ["OMPL_ROBOT_GRIPPER"] = "/Panda/Panda_gripper"

# Import interface and actions
from simulation.coppeliasim_interface_ur10 import CoppeliaSimInterfaceUR10
from simulation.actions import Actions


def main():
    print("=" * 60)
    print("TEST: Pick and Place with UR10 + ROBOTIQ85")
    print("=" * 60)
    
    # Step 1: Initialize interface
    print("\n[Step 1] Initializing interface...")
    sim_interface = CoppeliaSimInterfaceUR10(port=23000)
    sim_interface.connect()
    sim_interface.initialize_handles()
    
    # Step 2: Get initial state
    print("\n[Step 2] Getting initial state...")
    state = sim_interface.get_current_state()
    print(f"  Blocks: {list(state['block_positions'].keys())}")
    print(f"  Goals: {list(state['goal_position'].keys())}")
    
    for name, pos in state['block_positions'].items():
        print(f"  {name} position: [{pos[0]:.3f}, {pos[1]:.3f}, {pos[2]:.3f}]")
    
    # Step 3: Create Actions
    print("\n[Step 3] Creating Actions...")
    actions = Actions(sim_interface)
    print("  Actions created successfully!")
    
    object_name = "A60"
    target_name = "A60_1_2_D"
    pick_affordances = ["pick-side"]
    place_affordances = ["place-top"]

    # Step 4: Test pick
    print("\n[Step 4] Testing pick affordances...")
    success = False
    for affordance in pick_affordances:
        print(f"  Attempting: actions.pick('{object_name}', affordance='{affordance}')")
        try:
            success = actions.pick(object_name, affordance=affordance)
            #success = actions.pick(object_name, affordance="pick-side")
            #success = True
            #exit()
            if success:
                print(f"  Pick SUCCEEDED with affordance='{affordance}'")
                break
            print(f"  Pick FAILED (returned False) with affordance='{affordance}'")
        except Exception as e:
            print(f"  Pick FAILED with exception using affordance='{affordance}': {e}")
            import traceback
            traceback.print_exc()
    if not success:
        return False
    
    # Wait a moment
    time.sleep(1.0)
    
    # Step 5: Test place (if pick succeeded)
    print("\n[Step 5] Testing place affordances...")
    for affordance in place_affordances:
        print(
            "  Attempting: actions.place("
            f"'{object_name}', '{target_name}', affordance='{affordance}')"
        )
        try:
            place_success = actions.place(object_name, target_name, affordance=affordance)
            if place_success:
                print(f"  Place SUCCEEDED with affordance='{affordance}'")
                break
            print(f"  Place FAILED (returned False) with affordance='{affordance}'")
        except Exception as e:
            print(f"  Place FAILED with exception using affordance='{affordance}': {e}")
            import traceback
            traceback.print_exc()
    
    # Summary
    print("\n" + "=" * 60)
    print("TEST COMPLETE")
    print("=" * 60)
    
    return True


if __name__ == '__main__':
    try:
        main()
    except KeyboardInterrupt:
        print("\nInterrupted by user")
    except Exception as e:
        print(f"\nFatal error: {e}")
        import traceback
        traceback.print_exc()
