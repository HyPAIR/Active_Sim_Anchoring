"""PDDL to OMPL Plan Executor.

This module executes PDDL recovery plans using the Actions class (OMPL-based).
Converts symbolic PDDL actions into robot pick/place operations with appropriate offsets.

Author: Yazz Warsame
"""

import time


class PDDLExecutor:
    """Executes PDDL plans using robot Actions."""
    
    def __init__(self, actions):
        """
        Args:
            actions: Actions instance from simulation.actions
        """
        self.actions = actions
    
    def parse_interventions_to_offsets(self, interventions):
        """Convert MCTS interventions to placement offsets.
        
        Args:
            interventions: List of (obj, action) tuples like [('B', 'left,0.015')]
            
        Returns:
            Dictionary mapping object -> (offset_x, offset_y, offset_z)
        """
        offsets = {}
        
        for obj, action in interventions:
            if ',' not in action:
                continue
            
            parts = action.split(',')
            if len(parts) != 2:
                continue
            
            direction = parts[0].strip()
            try:
                magnitude = float(parts[1].strip())
            except ValueError:
                continue
            
            # Convert direction to offset
            # Coordinate system: +X right, +Y forward, +Z up
            offset_map = {
                'left': (-magnitude, 0, 0),
                'right': (magnitude, 0, 0),
                'forward': (0, magnitude, 0),
                'back': (0, -magnitude, 0)
            }
            
            if direction in offset_map:
                offsets[obj] = offset_map[direction]
        
        return offsets
    
    def execute_plan(self, plan_actions, interventions):
        """Execute PDDL plan with robot actions.
        
        Args:
            plan_actions: List of (action_name, parameters) tuples from PDDL
            interventions: List of (obj, action) tuples from MCTS
            
        Returns:
            True if all actions succeeded, False otherwise
        """
        print("\n" + "="*60)
        print("EXECUTING RECOVERY PLAN")
        print("="*60)
        
        # Parse offsets from interventions
        offsets = self.parse_interventions_to_offsets(interventions)
        print(f"\n[Executor] Computed offsets: {offsets}")
        
        # Execute each action
        for i, (action_name, params) in enumerate(plan_actions, 1):
            print(f"\n[Executor] Step {i}/{len(plan_actions)}: {action_name} {params}")
            
            success = self._execute_action(action_name, params, offsets)
            
            if not success:
                print(f"[Executor] FAILURE at step {i}")
                return False
            
            print(f"[Executor] Step {i}: SUCCESS")
            time.sleep(0.5)
        
        print("\n[Executor] All actions completed successfully!")
        return True
    
    def _execute_action(self, action_name, params, offsets):
        """Execute a single PDDL action.
        
        Args:
            action_name: PDDL action name (e.g., 'unstack', 'stack-target')
            params: List of parameters (block names)
            offsets: Dictionary of object -> offset tuple
            
        Returns:
            True if successful, False otherwise
        """
        if action_name == 'pickup-from-table':
            return self._pickup_from_table(params)
        
        elif action_name == 'putdown-to-table':
            return self._putdown_to_table(params, offsets)  # Pass offsets
        
        elif action_name == 'unstack':
            return self._unstack(params)
        
        elif action_name == 'stack':
            return self._stack(params, offsets, use_target=False)
        
        elif action_name == 'stack-target':
            return self._stack(params, offsets, use_target=True)
        
        else:
            print(f"[Executor] Unknown action: {action_name}")
            return False
    
    def _pickup_from_table(self, params):
        """Execute pickup-from-table action.
        
        Args:
            params: [block] - block to pick from table
        """
        if len(params) != 1:
            print(f"[Executor] pickup-from-table expects 1 param, got {len(params)}")
            return False
        
        block = params[0]
        
        # Handle occluder naming (occ_1, not Block_OCC_1)
        if block.startswith('OCC_'):
            block_name = block.lower()  # OCC_1 -> occ_1
        else:
            block_name = f"Block_{block}"
        
        return self.actions.pick(block_name, affordance="pick-top")
    
    def _putdown_to_table(self, params, offsets):
        """Execute putdown-to-table action.
        
        Args:
            params: [block] - block to place on table
            offsets: Dictionary of object -> offset tuple
        """
        if len(params) != 1:
            print(f"[Executor] putdown-to-table expects 1 param, got {len(params)}")
            return False

        block = params[0]
        
        # Handle occluder naming (OCC_1 -> occ_1)
        if block.startswith('OCC_'):
            block_name = block.lower()  # OCC_1 -> occ_1
            
            # For occluders, use intervention offset
            if block_name in offsets:
                offset = offsets[block_name]
                print(f"[Executor] Moving {block_name} with offset {offset}")
                return self.actions.place(block_name, block_name, offset=offset, yaw_offset=0.0)
        else:
            block_name = f"Block_{block}"
        
        # Regular blocks: place nearby on table
        return self.actions.place(block_name, block_name, offset=(0.1, 0, 0), yaw_offset=0.0)
    
    def _unstack(self, params):
        """Execute unstack action.
        
        Args:
            params: [upper, lower] - unstack upper from lower
        """
        if len(params) != 2:
            print(f"[Executor] unstack expects 2 params, got {len(params)}")
            return False
        
        upper = params[0]
        upper_name = f"Block_{upper}"
        
        return self.actions.pick(upper_name, affordance="pick-top")
    
    def _stack(self, params, offsets, use_target=False):
        """Execute stack or stack-target action.
        
        Args:
            params: [upper, lower] - stack upper on lower
            offsets: Dictionary of object -> offset tuple
            use_target: If True, use offset from interventions (stack-target)
        """
        if len(params) != 2:
            print(f"[Executor] stack expects 2 params, got {len(params)}")
            return False
        
        upper, lower = params[0], params[1]
        upper_name = f"Block_{upper}"
        lower_name = f"Block_{lower}"
        
        # Determine offset
        if use_target and upper in offsets:
            offset = offsets[upper]
            print(f"[Executor] Using target offset for {upper}: {offset}")
        else:
            offset = (0.0, 0.0, 0.0)
        
        return self.actions.place(upper_name, upper_name, offset=offset, yaw_offset=0.0)


class SimplePlanExecutor:
    """Executes simple pre-planned pick/place actions with affordances."""

    def __init__(self, actions, state_extractor=None):
        self.actions = actions
        self.state_extractor = state_extractor

    def _report_state(self, object_name, target_name=None):
        if not self.state_extractor:
            return
        state = self.state_extractor.extract_state()
        rels = state.get("relationships", [])
        holding = f"Holding({object_name})" in rels
        on_any = any(r.startswith(f"On({object_name},") for r in rels)
        on_target = target_name and any(
            r.startswith(f"On({object_name},") and target_name in r for r in rels
        )
        print(
            f"[State] Holding({object_name})={holding} "
            f"On({object_name},*)={on_any} "
            f"OnTarget({object_name},{target_name})={bool(on_target)}"
        )

    def execute_plan(self, plan_steps):
        print("\n" + "=" * 60)
        print("EXECUTING PRE-PLANNED ACTIONS")
        print("=" * 60)

        for i, step in enumerate(plan_steps, 1):
            action = step.get("action")
            obj = step.get("object")
            affordance = step.get("affordance")
            target = step.get("target")

            print(f"\n[Executor] Step {i}/{len(plan_steps)}: {action} {obj} -> {target}")

            if action == "pick":
                ok = self.actions.pick(obj, affordance=affordance or "pick-top")
                self._report_state(obj, target)
            elif action == "place":
                ok = self.actions.place(obj, target, affordance=affordance or "place-top")
                self._report_state(obj, target)
            else:
                print(f"[Executor] Unknown action: {action}")
                return False

            if not ok:
                print(f"[Executor] FAILURE at step {i}")
                return False

            print(f"[Executor] Step {i}: SUCCESS")
            time.sleep(0.5)

        print("\n[Executor] All actions completed successfully!")
        return True


def execute_recovery(sim_interface, plan_actions, interventions):
    """Execute PDDL recovery plan using OMPL-based actions.
    
    Args:
        sim_interface: CoppeliaSimInterface instance
        plan_actions: List of (action_name, parameters) tuples from PDDL planner
        interventions: List of (obj, action) tuples from MCTS identification
        
    Returns:
        True if recovery succeeded, False otherwise
    """
    from simulation.actions import Actions
    
    # Create Actions instance
    actions = Actions(sim_interface)
    
    # Create executor
    executor = PDDLExecutor(actions)
    
    # Execute plan
    success = executor.execute_plan(plan_actions, interventions)
    
    return success


def execute_preplanned(sim_interface, plan_json_path):
    """Execute a pre-made JSON plan of pick/place actions.

    Plan format:
    [
      {"action": "pick", "object": "A60", "affordance": "pick-side"},
      {"action": "place", "object": "A60", "target": "A60_1_2_D", "affordance": "place-top"}
    ]
    """
    import json
    from simulation.actions import Actions
    from simulation.symbolic_state import SymbolicStateExtractor

    with open(plan_json_path, "r") as f:
        plan_steps = json.load(f)

    actions = Actions(sim_interface)
    extractor = SymbolicStateExtractor(sim_interface)
    executor = SimplePlanExecutor(actions, state_extractor=extractor)
    return executor.execute_plan(plan_steps)
