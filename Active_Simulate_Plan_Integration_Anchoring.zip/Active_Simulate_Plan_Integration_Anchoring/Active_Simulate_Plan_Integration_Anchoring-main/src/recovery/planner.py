"""PDDL Recovery Planner for Block Stacking.

This module orchestrates the recovery planning process by generating PDDL problems
from MCTS results and running Fast Downward to produce action sequences.

Author: Yazz Warsame
"""

import json
import sys
import subprocess
from pathlib import Path
from pddl_builder import PDDLBuilder
from plan_parser import PlanParser


def run_recovery_planning(anomaly_num, identification_dir, config_dir, recovery_dir):
    """Generate PDDL recovery plan from MCTS identification results.
    
    Args:
        anomaly_num: Anomaly number (1, 2, or 3)
        identification_dir: Path to identification directory with results
        config_dir: Path to config directory with anomaly files
        recovery_dir: Path to recovery directory for PDDL output
        
    Returns:
        Tuple of (plan_actions, target_objects, interventions):
            - plan_actions: List of (action_name, parameters) tuples
            - target_objects: List of objects that need correction
            - interventions: List of (obj, action) tuples from MCTS
            
    Raises:
        FileNotFoundError: If required files are missing
        RuntimeError: If Fast Downward fails
    """
    print("\n" + "="*60)
    print(f"PDDL RECOVERY PLANNING FOR ANOMALY {anomaly_num}")
    print("="*60)
    
    # Load MCTS results
    results_file = Path(identification_dir) / f"results_anomaly_{anomaly_num}.json"
    if not results_file.exists():
        raise FileNotFoundError(f"MCTS results not found: {results_file}")
    
    with open(results_file, 'r') as f:
        mcts_results = json.load(f)
    
    interventions = mcts_results.get('interventions', [])
    target_objects = list(set(obj for obj, action in interventions))
    
    print(f"\n[Planner] Loaded MCTS results: {len(target_objects)} objects need correction")
    print(f"[Planner] Target objects: {target_objects}")
    print(f"[Planner] Interventions: {interventions}")
    
    # Load anomaly state (current state)
    anomaly_file = Path(config_dir) / f"anomaly_{anomaly_num}.json"
    if not anomaly_file.exists():
        raise FileNotFoundError(f"Anomaly config not found: {anomaly_file}")
    
    # For PDDL, we need symbolic relationships, not just positions
    # We'll use a simplified current state based on the anomaly
    # In practice, you'd extract this from the simulator
    if anomaly_num == 1:
        current_state = {
    'relationships': [
        'On(A,Goal_1)',
        'On(B,A)',
         '(not (Obstructing occ_1))' 
    ]
}
    
    if anomaly_num == 2:
        current_state = {
            'relationships': [
                'On(A,Goal_1)',
                'Clear(A)',
                'OnTable(occ_1)',      # No outer parens
                'Clear(occ_1)',        # No outer parens
                'Obstructing(occ_1)'
            ]
        }
    
    if anomaly_num == 3:
        current_state = {
            'relationships': [
                'On(A,Goal_1)',
                'On(B,A)',
                'Clear(B)',
                'OnTable(occ_1)',      # No outer parens
                'Clear(occ_1)',        # No outer parens
                'Obstructing(occ_1)'
            ]
        }

    # Goal state (same for all anomalies in this workshop)
    if anomaly_num == 1:
        goal_state = [
        
            'On(A,Goal_1)',
            'On(B,A)',
        ]
    elif anomaly_num == 2:
        goal_state = [
            'On(A,Goal_1)',
            'Clear(A)',
            '(not (Obstructing occ_1))'   # This one is raw PDDL, so keep parens
        ]
    else:
        goal_state = [
        'On(A,Goal_1)',
        'On(B,A)',
        '(not (Obstructing occ_1))'   # This one is raw PDDL, so keep parens
    ]
    
    # Generate PDDL problem
    builder = PDDLBuilder()
    pddl_problem = builder.generate_problem(
        current_state=current_state,
        goal_state=goal_state,
        target_objects=target_objects
    )
    
    # Set up directories
    work_dir = Path(recovery_dir) / 'fd_output'
    work_dir.mkdir(parents=True, exist_ok=True)
    
    # Write PDDL files
    problem_path = work_dir / 'problem.pddl'
    with open(problem_path, 'w') as f:
        f.write(pddl_problem)
    print(f"\n[Planner] Wrote problem: {problem_path}")
    
    # Locate domain file
    domain_path = Path(recovery_dir) / 'domains' / 'domain_s1.pddl'
    if not domain_path.exists():
        raise FileNotFoundError(f"Domain file not found: {domain_path}")
    
    # Run Fast Downward
    plan_file = run_fast_downward(domain_path, problem_path, work_dir)
    print(f"[Planner] Plan generated: {plan_file}")
    
    # Parse plan
    parser = PlanParser()
    plan_actions = parser.parse_plan_file(plan_file)
    
    print(f"\n[Planner] Plan has {len(plan_actions)} actions")
    
    # Save plan to JSON
    plan_json_path = work_dir / f'plan_anomaly_{anomaly_num}.json'
    with open(plan_json_path, 'w') as f:
        json.dump(
            [{'action': name, 'args': params} for name, params in plan_actions],
            f,
            indent=2
        )
    print(f"[Planner] Plan saved to: {plan_json_path}")
    
    return plan_actions, target_objects, interventions


def run_fast_downward(domain_path, problem_path, work_dir):
    """Execute Fast Downward planner.
    
    Args:
        domain_path: Path to PDDL domain file
        problem_path: Path to PDDL problem file
        work_dir: Working directory where Fast Downward will write output
        
    Returns:
        Path to the generated plan file (sas_plan)
        
    Raises:
        RuntimeError: If Fast Downward fails to find a plan
    """
    work_dir = Path(work_dir).resolve()
    work_dir.mkdir(parents=True, exist_ok=True)
    
    # Locate fast-downward.py - try multiple locations
    search_paths = [
        Path(work_dir).parent.parent / 'downward' / 'fast-downward.py',
        Path(work_dir) / 'downward' / 'fast-downward.py',
        Path(__file__).parent / 'downward' / 'fast-downward.py',
    ]
    
    fd_script = None
    for path in search_paths:
        if path.exists():
            fd_script = path
            break
    
    if not fd_script:
        raise FileNotFoundError(
            f"Fast Downward script not found. Searched in:\n" +
            "\n".join(f"  {p}" for p in search_paths)
        )
    
    # Build command
    cmd = [
        sys.executable,
        str(fd_script),
        str(domain_path),
        str(problem_path),
        "--search", "astar(lmcut())"
    ]
    
    print(f"\n[Planner] Running Fast Downward...")
    print(f"[Planner] Working directory: {work_dir}")
    
    # Run planner
    result = subprocess.run(
        cmd,
        cwd=str(work_dir),
        capture_output=True,
        text=True
    )
    
    # Check for success
    if result.returncode != 0:
        print(result.stdout)
        print(result.stderr)
        raise RuntimeError("Fast Downward failed to find a plan")
    
    # Find plan file
    plan_file = work_dir / 'sas_plan'
    if not plan_file.exists():
        # Check for numbered plans
        numbered_plans = list(work_dir.glob('sas_plan.*'))
        if numbered_plans:
            plan_file = max(numbered_plans, key=lambda p: int(p.suffix[1:]) if p.suffix[1:].isdigit() else 0)
        else:
            raise FileNotFoundError("Fast Downward did not produce a plan file")
    
    return plan_file