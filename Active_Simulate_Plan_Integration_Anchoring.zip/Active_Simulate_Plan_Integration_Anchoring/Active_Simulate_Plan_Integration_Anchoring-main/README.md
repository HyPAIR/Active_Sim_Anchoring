# MCTS-Based Anomaly Identification and Recovery for Robotic Manipulation

This repository demonstrates a complete pipeline for identifying and recovering from anomalies in robotic block stacking tasks using Monte Carlo Tree Search (MCTS), PDDL planning, and OMPL motion planning.

## System Overview

The system combines:
- **MCTS Identification**: Discovers minimal causal interventions to restore goal-achievability
- **Symbolic Reasoning**: PDDL-based task planning with geometric awareness
- **Motion Planning**: OMPL for collision-free pick-and-place execution
- **Simulation**: CoppeliaSim for physics-based validation

## Architecture

```
├── src/
│   ├── simulation/          # CoppeliaSim interface, state extraction, actions
│   ├── active-plan/
│   │   ├── identification/  # MCTS anomaly identification
│   │   └── config/          # Anomaly scenarios
│   └── recovery/            # PDDL planning and execution
```

## Prerequisites

### System Requirements
- Ubuntu 22.04 (recommended)
- Python 3.8+
- CoppeliaSim Edu V4.7.0+

### Dependencies
```bash
# Python packages
pip install numpy scipy

# Fast Downward planner (for recovery)
cd src/recovery
git clone https://github.com/aibasel/downward.git
cd downward
./build.py
```

### CoppeliaSim Setup
1. Download CoppeliaSim Edu from https://www.coppeliarobotics.com/downloads
2. Extract to your home directory
3. Update paths in `launch_coppelia.sh`

## Quick Start

### 1. Launch CoppeliaSim
```bash
chmod +x launch_coppelia.sh
./launch_coppelia.sh
```

This opens CoppeliaSim with the anomaly detection scene on port 23000.

### 2. Run Workshop Demonstrations

Navigate to the identification directory:
```bash
cd src/active-plan/identification
```

#### Nominal Execution (No Anomalies)
```bash
python3 runner.py --mode nominal
```
**Expected**: Robot stacks A→Goal, B→A, C→B successfully.

#### Show Failure Scenarios
```bash
# Misalignment failure (C collapses on misaligned B)
python3 runner.py --mode show_failure --failure misalignment

# Occlusion failure (robot collides with obstacle)
python3 runner.py --mode show_failure --failure occlusion
```
**Expected**: Tower collapses or collision occurs.

#### Anomaly Identification (MCTS)
```bash
# Anomaly 1: Misalignment only (B offset on A)
python3 runner.py --mode identify --anomaly 1 --iterations 50

# Anomaly 2: Occlusion only (occ_1 blocks placement)
python3 runner.py --mode identify --anomaly 2 --iterations 50

# Anomaly 3: Mixed (both misalignment and occlusion)
python3 runner.py --mode identify --anomaly 3 --iterations 50
```
**Expected**: MCTS discovers interventions and saves to `results_anomaly_N.json`.

**Sample Output (Anomaly 1)**:
```
[MCTS] Best sequence: [('B', 'left,0.015')]
Results saved to: results_anomaly_1.json
```

#### Recovery Execution (PDDL + OMPL)
```bash
# Recover from anomaly 1
python3 runner.py --mode recover --anomaly 1

# Recover from anomaly 2
python3 runner.py --mode recover --anomaly 2

# Recover from anomaly 3
python3 runner.py --mode recover --anomaly 3
```
**Expected**: Robot applies interventions, plans symbolic actions, and executes recovery.

## System Details

### Anomaly Types

**Anomaly 1: Misalignment**
- Block B is geometrically misaligned on A
- Symbolically correct: `On(B,A)` satisfied
- Geometrically incorrect: B's position offset causes instability
- Solution: MCTS identifies shift intervention (e.g., `left,0.015`)

**Anomaly 2: Occlusion**
- Occluder `occ_1` blocks placement area
- Motion planner cannot reach target
- Solution: MCTS identifies moving occluder away (e.g., `left,0.4`)

**Anomaly 3: Mixed**
- Both misalignment and occlusion present
- Requires multiple interventions
- Solution: MCTS discovers sequence of corrections

### MCTS Identification

The MCTS planner:
1. Loads anomaly configuration
2. Explores intervention space (shift actions)
3. Evaluates outcomes via simulation rollouts
4. Tracks violations (e.g., collapses)
5. Returns minimal intervention sequence

**Key Parameters**:
- `--iterations`: MCTS iterations (default: 50)
- Exploration constant: 1.414 (UCB balance)
- Actions: Shifts in 4 directions × 4 magnitudes

**Output**: `results_anomaly_N.json`
```json
{
  "anomaly": "anomaly_1",
  "interventions": [["B", "left,0.015"]],
  "iterations": 49,
  "solution_found": true
}
```

### PDDL Recovery

The recovery planner:
1. Reads MCTS results
2. Generates PDDL problem with "Target Trick"
3. Runs Fast Downward planner
4. Executes plan with OMPL motion planner

**Target Trick**: Objects identified by MCTS get special predicates:
- Initial: `(TargetOn B A)` - marks B needs precise placement
- Goal: `(AtTarget B)` - forces use of `stack-target` action
- Effect: Planner uses intervention offsets for geometric correction

**PDDL Actions**:
- `pickup-from-table`, `putdown-to-table`: Table operations
- `unstack`, `stack`: Standard block operations
- `stack-target`: Precise placement with offset

**Output**: `plan_anomaly_N.json`
```json
[
  {"action": "unstack", "args": ["B", "A"]},
  {"action": "stack-target", "args": ["B", "A"]}
]
```

### OMPL Execution

The executor:
1. Converts PDDL actions to robot operations
2. Computes offsets from interventions
3. Calls `Actions.pick()` and `Actions.place()`
4. Uses dummy target approach for offset placement

**Offset Conversion**:
- `left,0.015` -> `(-0.015, 0, 0)`
- `right,0.02` -> `(0.02, 0, 0)`
- `forward,0.01` -> `(0, 0.01, 0)`
- `back,0.015` -> `(0, -0.015, 0)`

## Configuration Files

### Anomaly Scenarios (`config/anomaly_N.json`)
```json
{
  "A": [-0.36, 0.55, 0.1095],
  "B": [-0.34, 0.55, 0.1685]  // Misaligned
}
```

### Intervention Configuration (`scenario1_intervention.json`)
Defines available intervention actions per object.

### Domain Definition (`recovery/domains/domain_s1.pddl`)
PDDL domain with `stack-target` action for precise placement.

## Troubleshooting

### CoppeliaSim Connection Failed
- Ensure CoppeliaSim is running
- Check port 23000 is not in use
- Verify ZMQ Remote API is enabled

### MCTS Not Converging
- Increase `--iterations` (try 100-200)
- Check alignment threshold in `scenario1_intervention.json`
- Verify anomaly is solvable (check logs for violations)

### Fast Downward Not Found
- Ensure `downward/fast-downward.py` exists in `recovery/`
- Run `./build.py` in downward directory
- Check Python interpreter path

### Motion Planning Fails
- Check OMPL state resolution (decrease for finer paths)
- Verify collision-free initial configuration

## Performance Notes

**MCTS Convergence**:
- Anomaly 1: ~10-15 iterations
- Anomaly 2: ~10-15 iterations
- Anomaly 3: ~30-50 iterations

**Planning Time**:
- Identification: 20-70s
- PDDL planning: <1s
- OMPL execution: 5-15s per action

## Repository Structure

```
.
├── launch_coppelia.sh           # CoppeliaSim launcher
├── README.md                    # This file
├── src/
│   ├── simulation/
│   │   ├── coppeliaSim_interface.py  # Sim communication
│   │   ├── symbolic_state.py         # State extraction
│   │   ├── actions.py                # Pick/place with OMPL
│   │   └── driver.py                 # OMPL planner interface
│   ├── active-plan/
│   │   ├── identification/
│   │   │   ├── runner.py             # Main entry point
│   │   │   ├── mcts_sim.py           # MCTS planner
│   │   │   ├── intervention_sim.py   # Intervention executor
│   │   │   └── scenario1_intervention.json
│   │   └── config/
│   │       ├── anomaly_1.json        # Misalignment scenario
│   │       ├── anomaly_2.json        # Occlusion scenario
│   │       └── anomaly_3.json        # Mixed scenario
│   └── recovery/
│       ├── planner.py                # PDDL planner
│       ├── pddl_builder.py           # Problem generator
│       ├── plan_parser.py            # Plan parser
│       ├── pddl_to_ompl.py           # Executor
│       └── domains/
│           └── domain_s1.pddl        # PDDL domain
```

